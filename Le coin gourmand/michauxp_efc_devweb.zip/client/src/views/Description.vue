<script setup>


</script>

<template>

    <div class="bg-white rounded-xl shadow-lg p-6   dark:bg-black  ">
        <h4 class="text-3xl font-title text-slate-800 dark:text-white text-center">Description du projet</h4>

        <p class="font-content text-xl dark:text-white p-5">Sur ce site vous trouverez des recettes de cuisine en tous
            genre
            que ce soit des entrées, plats et desserts de tous les continents. Dans les recettes vous trouverez notament
            le temps pour la réaliser, les ingrédients, le visuel de la recette fini et bien évidament les étapes pour
            mener a bien la recette. Vous
            pourez également ajouter des recettes, les modifiers et les supprimer à votre guise.
        </p>

        <p class="font-content text-xl dark:text-white p-5">Ce site est réalisé dans le cadre de l'EFC de DevWeb de la
            session d'automne 2025 du CÉGEP de Matane.</p>

        <p class="font-content text-xl dark:text-white p-5"> Ce site fonctionne avec une API REST pour récupérer les
            données
            qui sont stocker dans une base de données
            PHPMyAdmin. Tout le front-end est géré avec TailwindCSS, du JS et un router pour changer de page. Le côté
            back-end est réalisé avec du JS, du SQL
        </p>

        <p class="font-content text-xl dark:text-white p-5">N'oubliez pas de rester gourmand c'est le principal !</p>

    </div>

</template>